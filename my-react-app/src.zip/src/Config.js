export var DARKMODE = false;

export function darkmodeToggle() {

  if (!DARKMODE) {
    DARKMODE = true;
  }
  else {
    DARKMODE = false;
  }
}